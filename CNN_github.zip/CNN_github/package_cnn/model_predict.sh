#!/bin/bash

cd image_classify/

#----------------- CNN code run for model building and testing ---------------------------

echo '------------- Model building started ---------------------------'
 python3 model_simulation.py

 python3 prediction.py

echo '------------- Predictions complete for the test set ---------------------------'

 cd ../
