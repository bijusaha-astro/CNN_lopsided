#!/bin/bash
 cd ../outputs/
mv record.txt prev_run/.
mv acc_loss.csv prev_run/.
mv acc_loss.png prev_run/.
mv confusion_matrix.png prev_run/.
mv model.png prev_run/.
mv output.csv prev_run/.
mv best_weights.h5 prev_run/.
cd ../package_cnn/

rm image_process/L/*
rm image_process/NL/*

cd image_classify/images/

  rm -rf training/L
  rm -rf validation/L
  rm -rf testing/L

  rm -rf training/NL
  rm -rf validation/NL
  rm -rf testing/NL

  mkdir training/L
  mkdir validation/L
  mkdir testing/L

  mkdir training/NL
  mkdir validation/NL
  mkdir testing/NL

  cd ../

 rm record.txt
 rm acc_loss.csv 
 rm acc_loss.png 
 rm confusion_matrix.png 
 rm model.png 
 rm output.csv 
 rm best_weights.h5 
 cd ../
echo 'Erasing results and cache from previous run'

