#!/bin/bash

####################### This part creates a number of rotated images ( 360/da fold ) ##########
for i in {90..360..90}
 do
  for file in *.jpeg
  do
    outfile=r"$i"_`basename $file .jpeg`.jpg
    echo convert "'$file'" -background black -rotate $i "'$outfile'"
  done 
 done > script1.txt
gm batch -echo on -feedback on script1.txt


####################### This part creates one blurred and one sharpened image ( 3 fold ) ##########
for file in *.jpg
 do
   outfile1=f`basename $file .jpg`.jpg
   outfile2=F`basename $file .jpg`.jpg
   echo convert "'$file'" -flip "'$outfile1'"
   echo convert "'$file'" -flop "'$outfile2'"
done > script2.txt
gm batch -echo on -feedback on script2.txt

####################### This part creates one blurred and one sharpened image ( 3 fold ) ##########
for file in *.jpg
 do
   outfile1=s`basename $file .jpg`.jpg
   outfile2=b`basename $file .jpg`.jpg
   echo convert "'$file'" -sharpen 0x.1 "'$outfile1'"
   echo convert "'$file'" -blur 0x.1 "'$outfile2'"
 done > script3.txt
gm batch -echo on -feedback on script3.txt

#################### This part creates images of different contrast ( 3 fold ) ################

#for file in *.jpg
# do
#  outfile1=lc`basename $file .jpg`.jpg 
#  outfile2=hc`basename $file .jpg`.jpg 
#  echo convert -contrast "'$file'" "'$outfile1'"
#  echo convert +contrast "'$file'" "'$outfile2'"
#  echo convert -contrast "'$outfile1'" "'$outfile1'"
#  echo convert +contrast "'$outfile2'" "'$outfile2'"
#  outfile11=l`basename $outfile1 .jpg`.jpg 
#  outfile22=h`basename $outfile2 .jpg`.jpg 
#  echo convert -contrast "'$outfile1'" "'$outfile11'"
#  echo convert +contrast "'$outfile2'" "'$outfile22'"
#  echo convert -contrast "'$outfile11'" "'$outfile11'"
#  echo convert +contrast "'$outfile22'" "'$outfile22'"
# done > script3.txt
#gm batch -echo on -feedback on script3.txt


################# Final processing for each image ( number of images remains constant ) ############ 
for file in *.jpg
 do
   echo convert "'$file'" -modulate 110,100 "'$file'"
   echo convert "'$file'" -size 256x256 -resize 256x256 "'$file'"
   echo convert "'$file'" -contrast "'$file'"
   echo convert "'$file'" -contrast "'$file'"
 done > script4.txt
gm batch -echo on -feedback on script4.txt
