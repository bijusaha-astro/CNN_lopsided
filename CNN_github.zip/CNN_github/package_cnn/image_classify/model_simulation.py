'''
This set of routines help in classifying the images modelling the best Cnn and predicting the image from the given CNN networks
'''
import os
import math
import time
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from alexnet import alex
from tensorflow.keras.models import load_model
from tensorflow.keras.utils import plot_model
from tensorflow.keras import activations
from tensorflow.keras.optimizers import SGD,Adam,Adadelta
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint
from tensorflow.keras.preprocessing.image import ImageDataGenerator

np.random.seed(1000)

start = time.time()
#----------------------------------------------------------------------------------------------------------------------
print (__doc__)
#----------------------------------------------------------------------------------------------------------------------

image_size = 256 		# Dimension of image ( in pixels )
batch_size = 64  		# batch size for training data set (64)
val_batch_size = 16 		# batch size for validation data set (16)
class_name = ['L', 'NL']	# classified input images has to be kept in folders with the same class names
epoch = 150			
epoch_step = None		 
patience = 20                   # original = 20 

#----------------------------------------------------------------------------------------------------------------------
image_path = 'images/'
model_name = 'less_more.h5'		#model weight to be saved
model_dir = os.path.join(os.getcwd(), 'saved_models')

#---------------------------------------------------------------------------------------------------------------------

#loading data for training and validation

train_data_gen = ImageDataGenerator(rescale=1./255.)
train_data = train_data_gen.flow_from_directory(image_path+'/training/', target_size = (image_size,image_size), class_mode= 'categorical', shuffle = True, batch_size = batch_size,color_mode='rgb')

valid_data_gen = ImageDataGenerator(rescale = 1./255.)
valid_data = valid_data_gen.flow_from_directory(image_path+'/validation/', target_size = (image_size,image_size), class_mode = 'categorical',shuffle = True, batch_size = val_batch_size,color_mode='rgb')

#---------------------------------------------------------------------------------------------------------------------
print ('\n\n')
print ('--------------------------------------------------------------------------------')
print ('\t ************************************************************** \t')
print ('\t\t\t\t Network parameters \n')
print ('\t Image Size = %d px'%image_size)
print ('\t Batch size = %d'%batch_size)
print ('\t validation batch size = %d'%val_batch_size)
print ('\t Number of epochs = %d'%epoch)
#print ('\t Steps per epoch = %d'%epoch_step)
print ('\t Patience level for early stopping = %d'%patience)
print ("\t Size of training set : %d"%(len(train_data.filenames)))
print ("\t Size of validation set : %d"%(len(valid_data.filenames)))
print ("\t Class indices : %s \n" %str(valid_data.class_indices))
print ('\t ************************************************************** \t')
print ('--------------------------------------------------------------------------------')
print ('\n\n')

file1 = open('record.txt', 'w')
file1.write ('Network parameters: \n')
file1.write ("Class indices : %s \n" %str(valid_data.class_indices))
file1.write ('Image Size = %d px\n'%image_size)
file1.write ('Batch size = %d\n'%batch_size)
file1.write ('Batch size for validation = %d\n'%val_batch_size)
file1.write ('Number of epochs = %d\n'%epoch)
#file1.write ('Steps per epoch = %d\n'%epoch_step)
file1.write ('Patience level for early stopping = %d\n'%patience)
file1.write ("Size of training set : %d\n"%(len(train_data.filenames)))
file1.write ("Size of validation set : %d\n"%(len(valid_data.filenames)))
file1.close()

#---------------------------------------------------------------------------------------------------------------------
#important step size calculations
sample_size = len(train_data.filenames)
steps = math.ceil(sample_size / float(batch_size))	
#val_steps =  steps;
val_steps =  math.ceil(len(valid_data.filenames) / float(val_batch_size));
#---------------------------------------------------------------------------------------------------------------------

model = alex(image_size)						#this function calls the alexnet model function 
plot_model(model,'model.png', show_shapes = True,rankdir = 'LR')	#plots the schematic of the model defined 
print (model.summary())		# prints model summary in terminal

#----------------------------------------------------------------------------------------------------------------------
opt = SGD(
	learning_rate = 5.e-5, 
	momentum= 0.9,
	decay = 2.e-4,
	clipnorm=1.0
	)
#learning rate is decreased. Initially 5.e-5

#opt = Adam(
#	learning_rate = 0.00001, 
#	beta_1=0.9, 
#	beta_2=0.999, 
#	epsilon=1e-08,
#	clipnorm=1.0
#	)

#opt = Adadelta(
#	learning_rate=0.00001, 
#	rho=0.95, 
#	epsilon=1e-07,
#	clipnorm=1.0
#	)

model.compile(
	loss='binary_crossentropy',
	optimizer=opt, 
	metrics=['accuracy']
	)			#compiling the model

es = EarlyStopping(
	monitor = 'val_loss', 
	mode = 'min', 
	verbose =1, 
	patience = patience
	)

cp = ModelCheckpoint(
	monitor = 'val_accuracy', 
	filepath = 'best_weights.h5', 
	verbose=1,
	save_best_only = True
	)

hist = model.fit(
	train_data, 
	validation_data = valid_data, 
	validation_steps = val_steps, 
	validation_batch_size=val_batch_size,
	epochs = epoch,
	steps_per_epoch = epoch_step,
	verbose = 2, 
	callbacks = [es,cp],
	shuffle=False
	) 	

#-------------------------------------------------------------------------------------------------------------------------

print (hist.history.keys())

output_data = {'train_acc':hist.history['accuracy'], 'train_loss':hist.history['loss'], 'val_acc':hist.history['val_accuracy'], 'val_loss':hist.history['val_loss']}
df = pd.DataFrame(output_data)
df.to_csv('acc_loss.csv',index = False, header = True, sep = '\t')

# plotting the accuracy and the loss functions 
plt.figure(1)
plt.subplot(211)
plt.plot(hist.history['accuracy'],c='blue',ls='--',lw=1.5)
plt.plot(hist.history['val_accuracy'],c='red',lw=1.5)
plt.legend(['Training','Validation'])
plt.ylabel('Accuracy')
plt.subplot(212)
plt.plot(hist.history['loss'],c='green',ls='--',lw=1.5)
plt.plot(hist.history['val_loss'],c='orange',lw=1.5)
plt.legend(['Training','Validation'])
plt.ylabel('Loss')
plt.xlabel('Epochs')
plt.savefig('acc_loss.png',dpi = 300)
plt.close()
#----------------------------------------------------------------------------------------------------------------------
# save the model at the given specific location
if not os.path.isdir(model_dir):
	os.makedirs(model_dir)
model_path = os.path.join(model_dir,model_name)
model.save(model_path)
print ('saved model at location: %s'%model_path)

#----------------------------------------------------------------------------------------------------------------------

