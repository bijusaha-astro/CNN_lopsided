#!/bin/bash
for file in *.jpeg
 do
   outfile1=n`basename $file .jpeg`.jpg
   echo convert "'$file'" -modulate 110,100 "'$outfile1'"
   echo convert "'$outfile1'" -size 256x256 -resize 256x256 "'$outfile1'"
   echo convert "'$outfile1'" -contrast "'$outfile1'"
   echo convert "'$outfile1'" -contrast "'$outfile1'"
 done > script4.txt
gm batch -echo on -feedback on script4.txt
rm *.jpeg
