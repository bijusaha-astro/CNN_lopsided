from keras.preprocessing.image import ImageDataGenerator
from keras import models
import math, numpy as np, pandas as pd, matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix,classification_report, accuracy_score, roc_auc_score

np.random.seed(1000)

batch_size=1
image_size=256
steps=1

test_data_gen = ImageDataGenerator(rescale = 1/255.)
testing_generator = test_data_gen.flow_from_directory('images/testing/', target_size = (image_size,image_size), class_mode ='categorical', color_mode="rgb", seed = 1000, shuffle = False)

print (testing_generator.class_indices)
class_name = testing_generator.class_indices.keys()
steps = math.ceil(len(testing_generator.filenames) / batch_size)

file1 = open('record.txt', 'a')
file1.write ('Size of testing set1 = %d\n'%(len(testing_generator.filenames)))
file1.write ('Testing batch size = %d\n'%batch_size)

mode = models.load_model('best_weights.h5')

predict = mode.predict(testing_generator, steps=steps)
print(predict, predict.shape)

# Get the predicted class
pred_class = np.argmax(predict, axis=1)


# Map integer predictions to class names
labels = (testing_generator.class_indices)
labels = dict((v, k) for k, v in labels.items())
prediction = [labels[k] for k in pred_class]

# Get class names in correct order
class_names_ordered = [labels[i] for i in range(len(labels))]

# Prepare output DataFrame
df = pd.DataFrame({
    'name': testing_generator.filenames,
    'prediction': prediction,
    class_names_ordered[0]: predict[:, 0],   # probability for class 0
    class_names_ordered[1]: predict[:, 1],   # probability for class 1
})

# Save to CSV
df.to_csv('output.csv', index=False, header=True, sep=',')

#accuracy scoring of the model on the test data set
print ("\nPercentage of prediction for this run is  : %f\n"%(accuracy_score(testing_generator.classes, pred_class)*100))
file1.write('Accuracy of prediction : %f\n'%(accuracy_score(testing_generator.classes, pred_class)*100))
file1.close()

#precission,recall and f1-score claculation
print(classification_report(testing_generator.classes, pred_class,target_names=class_name))
cm = confusion_matrix(testing_generator.classes, pred_class)

cmat=np.zeros(4).reshape(2,2)

cmat[0,0]=round(float(cm[0,0])/float(cm[0,0]+cm[0,1]),2)
cmat[0,1]=round(float(cm[0,1])/float(cm[0,0]+cm[0,1]),2)
cmat[1,0]=round(float(cm[1,0])/float(cm[1,0]+cm[1,1]),2)
cmat[1,1]=round(float(cm[1,1])/float(cm[1,0]+cm[1,1]),2)

file2 = open('cm.txt', 'w')
for i in range(2):	
	for j in range(2):	
		file2.write ('%f '%cmat[i][j])
	file2.write('\n')
file2.close()

file2 = open('cm_p.txt', 'w')
for i in range(2):	
	for j in range(2):	
		file2.write ('%f '%cm[i][j])
	file2.write('\n')
file2.close()

#plotting the confusion matrix 
plt.figure(2)
plt.imshow(cmat,cmap=plt.cm.Blues)
plt.xlabel("Predicted labels")
plt.ylabel("True labels")
tick_marks = np.arange(len(class_name))
plt.xticks(tick_marks,class_name, rotation  = 0)
plt.yticks(tick_marks,class_name)
plt.title('Confusion matrix ')
thresh = cmat.max() / 2.
for i in range(cm.shape[0]):
   for j in range(cm.shape[1]):
        plt.text(j, i, format(cmat[i, j]), horizontalalignment="center",color= "black")
plt.colorbar()
plt.savefig('confusion_matrix.png',dpi = 300)
#plt.show()
plt.close(2)
