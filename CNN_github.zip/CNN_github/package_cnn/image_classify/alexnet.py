
from keras.models import Sequential
from keras.layers import Dense, Activation, Dropout, Flatten, Conv2D, MaxPooling2D
from keras.layers.normalization import BatchNormalization
import numpy as np
np.random.seed(1000)

def alex(image_size):
        model = Sequential()
        model.add(Conv2D(filters=96, input_shape=(image_size,image_size,3), kernel_size=(11,11), strides=(4,4), padding='valid',activation = 'relu'))
        model.add(MaxPooling2D(pool_size=(3,3), strides=(2,2), padding='valid'))
        model.add(BatchNormalization())
# 2nd Convolutional Layer
        model.add(Conv2D(filters=256, kernel_size=(5,5), strides=(1,1), padding='valid',activation = 'relu'))
        model.add(MaxPooling2D(pool_size=(3,3), strides=(2,2), padding='valid'))
        model.add(BatchNormalization())
# 3rd Convolutional Layer
        model.add(Conv2D(filters=384, kernel_size=(3,3), strides=(1,1), padding='valid',activation = 'relu'))
# 4th Convolutional Layer
        model.add(Conv2D(filters=384, kernel_size=(3,3), strides=(1,1), padding='valid',activation = 'relu'))
# 5th Convolutional Layer
        model.add(Conv2D(filters=256, kernel_size=(3,3), strides=(1,1), padding='valid',activation = 'relu'))
        model.add(MaxPooling2D(pool_size=(3,3), strides=(2,2), padding='valid'))
# Passing it to a Fully Connected layer
        model.add(Flatten())
# 1st Fully Connected Layer
        model.add(Dense(4096,activation = 'relu'))
# Add Dropout to prevent overfitting
        model.add(Dropout(0.5))
# 2nd Fully Connected Layer
        model.add(Dense(4096,activation = 'relu'))
# Add Dropout
        model.add(Dropout(0.5))
# Output Layer
        model.add(Dense(2, activation = 'softmax'))
        return model

