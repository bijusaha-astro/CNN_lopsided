'''
This routine helps in loadinf data and augmenting them for a better learning experinece and more optimized result
'''
from keras.preprocessing.image import ImageDataGenerator

def train_gen(image_path, batch_size,size):
	train_data_gen = ImageDataGenerator(rescale=1./255.)
	train_set = train_data_gen.flow_from_directory(image_path+'/training/', target_size = (size,size), class_mode= 'categorical', shuffle = True, batch_size = batch_size)
	return train_set


def valid_gen(image_path, batch_size,size):
	valid_data_gen = ImageDataGenerator(rescale = 1./255.)
	valid_set = valid_data_gen.flow_from_directory(image_path+'/validation/', target_size = (size,size), class_mode = 'categorical',shuffle = True, batch_size = batch_size)
	return valid_set

