#!/bin/bash
cp ../input_images/L/*.jpeg image_process/L/.
cp ../input_images/NL/*.jpeg image_process/NL/.

cd image_process/L/

  nf=$(ls -F |grep -v / | wc -l)
  nf2=$((nf/5))
  ls | shuf -n $nf2 | xargs -i mv {} ../../image_classify/images/testing/L/.
  cp ../../image_classify/aug_script.sh .
  ./aug_script.sh
  rm script*
  rm aug_script.sh
  rm *.jpeg
  nf=$(ls -F |grep -v / | wc -l)
  nf2=$((nf/5))
  ls | shuf -n $nf2 | xargs -i mv {} ../../image_classify/images/validation/L/.
  mv * ../../image_classify/images/training/L/.

  cd ../NL/
  nf=$(ls -F |grep -v / | wc -l)
  nf2=$((nf/5))
  ls | shuf -n $nf2 | xargs -i mv {} ../../image_classify/images/testing/NL/. 
  cp ../../image_classify/aug_script.sh .
  ./aug_script.sh
  rm script*
  rm aug_script.sh
  rm *.jpeg
  nf=$(ls -F |grep -v / | wc -l)
  nf2=$((nf/5))
  ls | shuf -n $nf2 | xargs -i mv {} ../../image_classify/images/validation/NL/.
  mv * ../../image_classify/images/training/NL/.
echo 'Augmentation of images for training and validation set done.'

  cd ../../image_classify/
 cp test_proc.sh images/testing/L/.
 cp test_proc.sh images/testing/NL/.

 cd images/testing/L/
    ./test_proc.sh
    rm test_proc.sh
    rm script*

    cd ../NL/
    ./test_proc.sh
    rm test_proc.sh
    rm script*

echo 'General modulations for testing set done.'
    cd ../../../../
