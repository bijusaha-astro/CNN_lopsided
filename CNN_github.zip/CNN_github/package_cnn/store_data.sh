#!/bin/bash
cd image_classify/
 mv record.txt ../../outputs/.
 mv acc_loss.csv ../../outputs/.
 mv acc_loss.png ../../outputs/.
 mv confusion_matrix.png ../../outputs/.
 mv model.png ../../outputs/.
 mv output.csv ../../outputs/.
 cp best_weights.h5 ../../outputs/.

echo '----------- Results stored in output directory -------------------' 
cd ../
