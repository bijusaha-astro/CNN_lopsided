#!/bin/bash
cd package_cnn/
 ./clear_last.sh

 ./prep_tvt.sh
 
 ./model_predict.sh
 
 ./store_data.sh
cd ../

echo '----------- Results stored in output directory -------------------' 
